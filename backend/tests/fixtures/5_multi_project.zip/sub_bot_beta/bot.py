import telebot, os
bot = telebot.TeleBot(os.getenv("BOT_TOKEN"))
if __name__ == '__main__':
    bot.infinity_polling()
