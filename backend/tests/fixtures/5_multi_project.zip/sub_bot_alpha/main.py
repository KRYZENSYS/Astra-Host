import asyncio, os
from aiogram import Bot, Dispatcher
dp = Dispatcher()
async def main():
    await dp.start_polling(Bot(os.getenv("BOT_TOKEN")))
if __name__ == '__main__':
    asyncio.run(main())
