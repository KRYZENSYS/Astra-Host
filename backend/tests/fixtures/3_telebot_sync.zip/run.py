import os
import telebot

TOKEN = os.getenv("BOT_TOKEN", "default_token")
bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "Salom TeleBot!")

if __name__ == '__main__':
    bot.infinity_polling()
