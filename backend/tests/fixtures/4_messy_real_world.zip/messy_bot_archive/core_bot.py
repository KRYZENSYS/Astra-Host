import os
import asyncio
import sqlite3
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command

# Connect to sqlite
db_conn = sqlite3.connect("bot_storage.db")

TOKEN = os.getenv("BOT_TOKEN")
SECRET_KEY = os.getenv("SECRET_KEY")
dp = Dispatcher()

@dp.message(Command("help"))
async def help_cmd(msg: types.Message):
    await msg.answer("Yordam matni")

async def main():
    bot = Bot(token=TOKEN)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
