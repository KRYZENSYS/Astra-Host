def hub_init(): return True
