#!/bin/bash
python core_bot.py
