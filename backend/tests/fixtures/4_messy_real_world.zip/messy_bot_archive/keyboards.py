def get_kb(): return None
