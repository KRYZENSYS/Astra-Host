def register(): pass
