ADMIN_ID = int(os.getenv('ADMIN_ID', '123456'))
