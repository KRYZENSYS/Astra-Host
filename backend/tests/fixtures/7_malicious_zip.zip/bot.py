print('safe')
